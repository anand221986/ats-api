--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: candidate_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.candidate_status AS ENUM (
    'Application',
    'Screening',
    'Interview',
    'Hired',
    'Rejected'
);


ALTER TYPE public.candidate_status OWNER TO postgres;

--
-- Name: education_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.education_enum AS ENUM (
    'High School',
    'Associate',
    'Bachelor',
    'Master',
    'Doctorate'
);


ALTER TYPE public.education_enum OWNER TO postgres;

--
-- Name: employment_type_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.employment_type_enum AS ENUM (
    'Full-time',
    'Part-time',
    'Contract',
    'Internship',
    'Temporary'
);


ALTER TYPE public.employment_type_enum OWNER TO postgres;

--
-- Name: experience_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.experience_enum AS ENUM (
    'Entry level',
    'Mid level',
    'Senior level',
    'Director',
    'Executive'
);


ALTER TYPE public.experience_enum OWNER TO postgres;

--
-- Name: hmapproval_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.hmapproval_status AS ENUM (
    'Pending',
    'Approved',
    'Rejected',
    'Not Required'
);


ALTER TYPE public.hmapproval_status OWNER TO postgres;

--
-- Name: job_priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.job_priority AS ENUM (
    'High',
    'Medium',
    'Low'
);


ALTER TYPE public.job_priority OWNER TO postgres;

--
-- Name: job_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.job_status AS ENUM (
    'Active',
    'Draft',
    'Paused',
    'Open',
    'Closed',
    'Archived'
);


ALTER TYPE public.job_status OWNER TO postgres;

--
-- Name: notice_period_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.notice_period_enum AS ENUM (
    '15 days',
    '30 days',
    '60 days',
    '90 days'
);


ALTER TYPE public.notice_period_enum OWNER TO postgres;

--
-- Name: recruiter_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.recruiter_status AS ENUM (
    'New Application',
    'Initial Review',
    'Screening Complete',
    'Recommended',
    'Not Suitable'
);


ALTER TYPE public.recruiter_status OWNER TO postgres;

--
-- Name: workplace_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.workplace_enum AS ENUM (
    'On-site',
    'Hybrid',
    'Remote'
);


ALTER TYPE public.workplace_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    actor_name character varying(255),
    action text,
    candidate_id integer,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO postgres;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    id integer NOT NULL,
    name character varying(255),
    email character varying(255),
    password character varying(255),
    created_dt timestamp without time zone
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: admin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_id_seq OWNER TO postgres;

--
-- Name: admin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_id_seq OWNED BY public.admin.id;


--
-- Name: applications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.applications (
    id integer NOT NULL,
    candidate_id integer,
    job_id integer,
    application_date date,
    status character varying(50)
);


ALTER TABLE public.applications OWNER TO postgres;

--
-- Name: applications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.applications_id_seq OWNER TO postgres;

--
-- Name: applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.applications_id_seq OWNED BY public.applications.id;


--
-- Name: candidate_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidate_jobs (
    candidate_id integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.candidate_jobs OWNER TO postgres;

--
-- Name: candidate_notes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidate_notes (
    id integer NOT NULL,
    candidate_id integer NOT NULL,
    author_id integer NOT NULL,
    note text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.candidate_notes OWNER TO postgres;

--
-- Name: candidate_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.candidate_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.candidate_notes_id_seq OWNER TO postgres;

--
-- Name: candidate_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.candidate_notes_id_seq OWNED BY public.candidate_notes.id;


--
-- Name: candidate_resumes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidate_resumes (
    id integer NOT NULL,
    candidate_id integer,
    resume_url text NOT NULL,
    uploaded_by text,
    uploaded_at timestamp without time zone DEFAULT now(),
    is_current boolean DEFAULT true
);


ALTER TABLE public.candidate_resumes OWNER TO postgres;

--
-- Name: candidate_resumes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.candidate_resumes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.candidate_resumes_id_seq OWNER TO postgres;

--
-- Name: candidate_resumes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.candidate_resumes_id_seq OWNED BY public.candidate_resumes.id;


--
-- Name: candidate_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.candidate_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.candidate_task_id_seq OWNER TO postgres;

--
-- Name: candidate_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidate_task (
    id integer DEFAULT nextval('public.candidate_task_id_seq'::regclass) NOT NULL,
    candidate_id integer NOT NULL,
    author_id integer,
    task text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.candidate_task OWNER TO postgres;

--
-- Name: candidates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.candidates (
    id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    headline character varying(255),
    phone character varying(255),
    address text,
    photo_url text,
    education text,
    experience text,
    summary text,
    cover_letter text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    status public.candidate_status DEFAULT 'Application'::public.candidate_status NOT NULL,
    recruiter_status public.recruiter_status DEFAULT 'New Application'::public.recruiter_status NOT NULL,
    hmapproval public.hmapproval_status DEFAULT 'Pending'::public.hmapproval_status NOT NULL,
    current_company text,
    current_ctc numeric(10,2),
    expected_ctc numeric(10,2),
    skill text[],
    college text,
    degree text,
    rating numeric(2,1),
    linkedinprofile character varying(255),
    institutiontier character varying(255),
    companytier character varying(255),
    resume_url text DEFAULT ''::text NOT NULL,
    notice_period character varying(50) DEFAULT '15 days'::character varying
);


ALTER TABLE public.candidates OWNER TO postgres;

--
-- Name: candidates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.candidates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.candidates_id_seq OWNER TO postgres;

--
-- Name: candidates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.candidates_id_seq OWNED BY public.candidates.id;


--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.client_id_seq OWNER TO postgres;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    id integer DEFAULT nextval('public.client_id_seq'::regclass) NOT NULL,
    name character varying(255) NOT NULL,
    website text,
    careers_page text,
    street1 text,
    street2 text,
    city character varying(100),
    state character varying(100),
    country character varying(100),
    zipcode character varying(20),
    linkedin text,
    phone character varying(30),
    tags text[],
    industry character varying(100),
    size character varying(50),
    currency character varying(10),
    revenue character varying(50),
    created_dt timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_dt timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email character varying(255),
    contact_person character varying(255)
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: contact_forms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_forms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255),
    phone character varying(50),
    message text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.contact_forms OWNER TO postgres;

--
-- Name: contact_forms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.contact_forms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_forms_id_seq OWNER TO postgres;

--
-- Name: contact_forms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.contact_forms_id_seq OWNED BY public.contact_forms.id;


--
-- Name: interviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interviews (
    id integer NOT NULL,
    application_id integer,
    scheduled_at timestamp without time zone,
    duration_minutes integer,
    type character varying(50),
    interviewer character varying(255)
);


ALTER TABLE public.interviews OWNER TO postgres;

--
-- Name: interviews_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.interviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interviews_id_seq OWNER TO postgres;

--
-- Name: interviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.interviews_id_seq OWNED BY public.interviews.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    job_title character varying(255) NOT NULL,
    job_code character varying(100),
    department character varying(255),
    workplace public.workplace_enum NOT NULL,
    office_primary_location character varying(255) NOT NULL,
    office_on_careers_page boolean DEFAULT true,
    office_location_additional text[],
    description_about text NOT NULL,
    description_requirements text,
    description_benefits text,
    company_industry character varying(255) NOT NULL,
    company_job_function character varying(255) NOT NULL,
    employment_type public.employment_type_enum NOT NULL,
    experience public.experience_enum NOT NULL,
    education public.education_enum NOT NULL,
    keywords text[],
    salary_from numeric(12,2),
    salary_to numeric(12,2),
    salary_currency character varying(10),
    status public.job_status DEFAULT 'Draft'::public.job_status NOT NULL,
    priority public.job_priority DEFAULT 'Medium'::public.job_priority NOT NULL,
    company character varying(255),
    about_company text,
    notice_period public.notice_period_enum DEFAULT '30 days'::public.notice_period_enum
);


ALTER TABLE public.jobs OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO postgres;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    phone character varying(255),
    password character varying(60),
    birthday date,
    gender integer DEFAULT 1 NOT NULL,
    marital_status integer DEFAULT 0 NOT NULL,
    address text,
    pin_code integer,
    state character varying(255),
    profile_pic text,
    email_verified integer DEFAULT 0,
    phone_verified integer DEFAULT 0,
    login_otp integer,
    login_otp_valid timestamp without time zone,
    status integer DEFAULT 1,
    created_dt timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    token text,
    role character varying(50) DEFAULT 'Recruiter'::character varying,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['Admin'::character varying, 'Candidate'::character varying, 'HiringManager'::character varying, 'Interviewer'::character varying, 'Recruiter'::character varying, 'Vendor'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO postgres;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_seq OWNED BY public.users.id;


--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_skills (
    id integer NOT NULL,
    skill text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_skills OWNER TO postgres;

--
-- Name: user_skills_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_skills_id_seq OWNER TO postgres;

--
-- Name: user_skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_skills_id_seq OWNED BY public.user_skills.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: admin id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin ALTER COLUMN id SET DEFAULT nextval('public.admin_id_seq'::regclass);


--
-- Name: applications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications ALTER COLUMN id SET DEFAULT nextval('public.applications_id_seq'::regclass);


--
-- Name: candidate_notes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_notes ALTER COLUMN id SET DEFAULT nextval('public.candidate_notes_id_seq'::regclass);


--
-- Name: candidate_resumes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_resumes ALTER COLUMN id SET DEFAULT nextval('public.candidate_resumes_id_seq'::regclass);


--
-- Name: candidates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidates ALTER COLUMN id SET DEFAULT nextval('public.candidates_id_seq'::regclass);


--
-- Name: contact_forms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_forms ALTER COLUMN id SET DEFAULT nextval('public.contact_forms_id_seq'::regclass);


--
-- Name: interviews id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews ALTER COLUMN id SET DEFAULT nextval('public.interviews_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: user_skills id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills ALTER COLUMN id SET DEFAULT nextval('public.user_skills_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, actor_name, action, candidate_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin (id, name, email, password, created_dt) FROM stdin;
1	admin	admin@gmail.com	thcadmin@2025	\N
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.applications (id, candidate_id, job_id, application_date, status) FROM stdin;
\.


--
-- Data for Name: candidate_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidate_jobs (candidate_id, job_id) FROM stdin;
99	34
99	26
99	25
98	21
98	20
95	34
95	19
96	34
96	26
96	25
96	21
93	34
93	26
89	34
89	26
89	25
\.


--
-- Data for Name: candidate_notes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidate_notes (id, candidate_id, author_id, note, created_at, updated_at) FROM stdin;
1	99	1	candidats is very good	2025-07-18 02:45:22.339568	2025-07-18 02:45:22.339568
2	99	1	candidats is good	2025-07-18 03:00:28.95784	2025-07-18 03:00:28.95784
4	98	1	good candidate	2025-07-18 06:20:28.25538	2025-07-18 06:20:28.25538
\.


--
-- Data for Name: candidate_resumes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidate_resumes (id, candidate_id, resume_url, uploaded_by, uploaded_at, is_current) FROM stdin;
4	\N	1753351411221-871191529.pdf	Admin	2025-07-24 10:03:53.608371	t
5	\N	1753351412006-452379354.pdf	Admin	2025-07-24 10:04:15.219393	t
6	\N	1753351602613-772438929.pdf	Admin	2025-07-24 10:07:00.5595	t
7	\N	1753351604412-779711970.pdf	Admin	2025-07-24 10:07:21.618607	t
8	\N	1753351604691-20501967.pdf	Admin	2025-07-24 10:07:35.16793	t
9	\N	1753351605072-337886654.pdf	Admin	2025-07-24 10:07:50.367533	t
10	\N	1753351605074-605859420.pdf	Admin	2025-07-24 10:08:04.901087	t
11	\N	1753351605075-591323298.pdf	Admin	2025-07-24 10:08:17.151894	t
12	\N	1753351605268-304976494.pdf	Admin	2025-07-24 10:08:37.632765	t
13	\N	1753351605452-394908874.pdf	Admin	2025-07-24 10:08:51.387817	t
14	\N	1753359721105-421936662.pdf	Admin	2025-07-24 12:22:18.955515	t
15	89	1753359722093-178201121.pdf	Admin	2025-07-24 12:22:39.591092	f
16	89	1753362303033-571367988.pdf	Admin	2025-07-24 13:05:19.544345	t
17	\N	1753458857783-809278058.pdf	Admin	2025-07-25 15:54:26.096605	t
18	\N	1753543396574-969726403.pdf	Admin	2025-07-26 15:23:22.493298	t
19	\N	1754040613691-676452693.pdf	Admin	2025-08-01 09:30:26.402753	t
20	\N	1754040613867-553350166.pdf	Admin	2025-08-01 09:30:37.661314	t
21	\N	1754040614044-735079004.pdf	Admin	2025-08-01 09:30:50.84915	t
22	\N	1754070005717-619929784.pdf	Admin	2025-08-01 17:40:19.820141	t
23	\N	1754206060014-501644338.pdf	Admin	2025-08-03 07:27:57.528168	t
\.


--
-- Data for Name: candidate_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidate_task (id, candidate_id, author_id, task, created_at, updated_at) FROM stdin;
5	88	1	added task	2025-07-25 14:33:44.054818	2025-07-25 14:33:44.054818
7	88	1	Follow up on interview feedback	2025-07-25 14:43:45.92783	2025-07-25 14:43:45.92783
4	1	1	task assigned	2025-07-25 14:31:12.853311	2025-07-25 14:31:12.853311
8	1	1	task 2 assigned	2025-07-25 15:47:26.192797	2025-07-25 15:47:26.192797
6	1	1	candidate has been assigned task 1	2025-07-25 14:39:08.47618	2025-07-25 14:39:08.47618
9	88	1	assigned task 	2025-07-25 15:49:50.101319	2025-07-25 15:49:50.101319
10	89	1	Candidate assessment	2025-07-25 16:08:13.301538	2025-07-25 16:08:13.301538
11	89	1	candidate selected	2025-07-25 16:21:22.626447	2025-07-25 16:21:22.626447
2	89	1	candidate is nice	2025-07-25 14:28:34.510637	2025-07-25 14:28:34.510637
3	89	1	task assigned 2	2025-07-25 14:29:49.719016	2025-07-25 14:29:49.719016
12	89	1	task 3	2025-07-25 16:27:22.891546	2025-07-25 16:27:22.891546
13	77	1	solve 50 sql	2025-07-29 08:14:11.614393	2025-07-29 08:14:11.614393
14	93	1	test the task1	2025-08-03 09:03:08.598731	2025-08-03 09:03:08.598731
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.candidates (id, first_name, last_name, email, headline, phone, address, photo_url, education, experience, summary, cover_letter, created_at, updated_at, status, recruiter_status, hmapproval, current_company, current_ctc, expected_ctc, skill, college, degree, rating, linkedinprofile, institutiontier, companytier, resume_url, notice_period) FROM stdin;
81	SHIVAM	MITTAL	mittalshivam44@gmail.com	\N	+91 7678578983	[{"firstline":"Delhi, India","city":"Delhi","pincode":null,"district":null,"state":null,"country":"India"}]	\N	[{"institution":"Institute of Chartered Accountants of India","degree":"Chartered Accountant","duration":"Feb 2021","percentage":null,"cgpa":null},{"institution":"Delhi University","degree":"Bachelor of Commerce (Honours)","duration":"Sept 2015","percentage":null,"cgpa":null}]	[{"company":"Mastercard","role":"Senior Financial Analyst (Contractual)","duration":"Oct 2024 – Present","responsibilities":["Managing the monthly close process by liaising between Accounts and Business teams to ensure seamless communication and accurate financial reporting.","Conducting detailed variance analysis (Actuals vs. Budget vs. Forecast) and preparing insightful commentaries to support management’s financial decision-making.","Collaborating with business stakeholders to prepare monthly forecasts and leading the preparation and finalization of the annual budget, including budget load into Oracle Hyperion for reporting accuracy.","Delivering management reporting, preparing KPI-focused decks, and addressing ad-hoc requests related to budgeting, actual spending, and future financial projections."]},{"company":"VLCC Healthcare Pvt. Ltd.","role":"Manager","duration":"Jun 2024 – Sep 2024","responsibilities":["Led the preparation of monthly MIS reports to drive informed decision-making and collaborated with cross-functional teams to ensure the accuracy of financial data.","Implemented automation strategies to streamline financial reporting processes and spearheaded financial planning initiatives to optimize operational efficiency.","Managed treasury operations and investment portfolios, analyzed accounts receivable aging to streamline collections, and ensured accurate financial reporting in compliance with regulatory standards.","Prepared and delivered MIS reports and financial commentaries for senior management, enabling strategic decision-making through variance analysis and performance forecasting.","Led budgeting processes and financial planning, including annual budgets and monthly assessments, while collaborating with business heads to drive profitability and enhance operational efficiency."]},{"company":"Unitedlex Pvt. Ltd.","role":"Financial Planning & Analyst","duration":"Jul 2021 – Jul 2022","responsibilities":["Led financial planning and analysis by preparing revenue commentaries, conducting receipt pattern analysis to project collections and DSO, and publishing comprehensive MIS reports integrating financials and business KPIs at the SBU level.","Managed budgeting and forecasting across all BUs using Oracle Hyperion, including annual plans, monthly assessments, variance analysis, and management commentaries.","Advised senior leadership on profitability and strategic decision-making through scenario modeling and simulations; managed month-end book closing and ensured accuracy in financial reporting."]},{"company":"Grant Thornton Advisory Pvt. Ltd.","role":"Financial Planning & Analyst (Contractual)","duration":"May 2023 – May 2024","responsibilities":[]}]	\N	\N	2025-07-24 10:07:35.152679	2025-07-24 10:07:35.152679	Screening	New Application	Pending	\N	\N	\N	{"Financial Planning and Analysis (FP&A)","Budgeting & Forecasting","Variance Analysis","Financial Reporting & MIS","Process Automation & Reporting","Financial Modeling","Stakeholder Management","Data Analysis & Visualization"}	\N	\N	\N	linkedin.com/in/ca-shivam-mittal	two	two	1753351604691-20501967.pdf	15 days
15	John	Utkarsh	admin@ats.com	Machine Learning Engineer	1234567890	123 Innovation Way, Suite 500, San Jose, California, USA, 71187	https://www.linkedin.com/company/acmetech	IIT Bhubaneswar	Google	summary	\N	2025-06-20 15:53:37.072199	2025-06-20 15:53:37.072199	Application	New Application	Pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		15 days
46	Kumar	Utkarsh	22cs01032@iitbbs.ac.in	\N			\N	[{"institution":"Indian Institute of Technology, Bhubaneswar","degree":"B.Tech in Computer Science and Engineering","startDate":"Nov 2022","endDate":"Present","GPA":7.45,"relevantCourses":["Data Structures & Algorithms","Database Management Systems","Operating Systems","Computer Networks","Object-Oriented Programming","Discrete Math","Data Mining"]},{"institution":"Army Public School, Danapur Cantonment","degree":"Senior Secondary Certificate (CBSE)","startDate":"Apr 2020","endDate":"Mar 2021","percentage":97.6}]	[{"company":"A1 Selectors","role":"Software Developer Intern","startDate":"May 2025","endDate":"Present","responsibilities":["Developing a scalable Applicant Tracking System (ATS) platform using React.js, ShadCN UI, and Tailwind CSS.","Built and integrated job posting and client onboarding modules with file upload (CSV/XLSX) and form validation.","Designed LinkedIn profile import interface, handling bulk URL parsing and API communication with a NestJS backend.","Collaborating via GitHub, using PR workflows and testing features in production-like environments on AWS."]}]	\N	\N	2025-07-14 15:44:56.90008	2025-07-14 15:44:56.90008	Hired	New Application	Pending	\N	\N	\N	{C,C++,JavaScript,Python,SQL,GraphQL,React.js,NestJS,Node.js,Express.js,Flask,Django,PostgreSQL,"Tailwind CSS","ShadCN UI",Git,GitHub,Jupyter,PyCharm}	\N	\N	\N	\N	\N	\N		15 days
9	Kumar	Utkarsh	smulani@cil.com	Full Stack Developer	+1-408-555-7890		https://www.linkedin.com/company/acmetech	iit bbs	intern	my summary	my cv	2025-06-17 08:12:20.612839	2025-06-17 08:12:20.612839	Application	New Application	Pending	StartupXYZ	80000.00	\N	\N	Parsons School of Design	MFA dESIGN	2.0	\N	\N	\N		15 days
20	Aisha	Khan	aisha.khan@example.com	Data Scientist	+91-9876543210		https://example.com/photos/aisha.jpg	M.Sc in Data Science	2 years at DataCorp	Expert in machine learning and statistical modeling.	Looking forward to driving insights with data.	2025-06-28 09:09:14.806609	2025-06-28 09:09:14.806609	Hired	Recommended	Approved	DataCorp	85000.00	100000.00	{}	Stanford University	Ph.D	4.8	\N	\N	\N		15 days
21	Ravi	Patel	ravi.patel@example.com	DevOps Engineer	+44-20-7946-0958		https://example.com/photos/ravi.jpg	B.Sc in IT	4 years at CloudOps	Skilled in AWS, Docker, and CI/CD pipelines.	Ready to enhance your infrastructure.	2025-06-28 09:09:14.810922	2025-06-28 09:09:14.810922	Interview	Not Suitable	Rejected	CloudOps	95000.00	110000.00	{}	Imperial College London	M.Sc	4.5	\N	\N	\N		15 days
10	Kumar	Utkarsh	kumar.cs01032@gmail.com	Full Stack Developer	+1-408-555-7890	123 Innovation Way, Suite 500, Patna, California, USA, 951127	https://www.linkedin.com/company/acmetech	my education	my experience	your summary	\N	2025-06-19 14:32:41.310767	2025-06-19 14:32:41.310767	Hired	New Application	Pending	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N		15 days
19	Tony	Stark	tony@example.com	Full Stack Developer	+1-408-555-7890	740 StViG St, Apt 842, San Jose, StateXiqq, Germany, 95112	https://www.linkedin.com/company/acmetech	my education	my experience	my summary	my cv	2025-06-25 07:49:59.69641	2025-06-25 07:49:59.69641	Hired	New Application	Pending	A1 selectors	100000.00	200000.00	{react,nest,postgres}	IIT Bhubaneswar	B.Tech	1.0	\N	\N	\N		15 days
1	John	Doe	john.doe@example.com	Senior Developer	+1234567890	123 Main Street, New York	https://example.com/photo.jpg	B.Sc in Computer Science	5 years in backend development	Passionate software engineer with expertise in Node.js and PostgreSQL.	I'm excited to apply for this role and contribute to your team.	2025-05-30 20:37:50.259195	2025-05-30 20:37:50.259195	Application	New Application	Pending	TechStart Inc	95000.00	\N	{node,pgp}	MIT	MCA	5.0	\N	\N	\N		30 days
48	Arun	Sharma	sharmaarun201295@gmail.com	\N	8298873232		\N	[{"degree":"Masters of Mathematics","institution":"Indian Statistical Institute, Bengaluru","graduationDate":"May 2023","score":"73.95%"},{"degree":"Bachelor of Technology (Hons.) in Electrical Engineering","institution":"Indian Institute of Technology (I.S.M.), Dhanbad","graduationDate":"May 2018","score":"7.1 OGPA"}]	[{"title":"Data Scientist","company":"Amazon","duration":"January 2024 - Present","details":["Developed anomaly detection and feature importance solutions using DeepVAR and EBMs","Leveraged Claude language model for generating insights and automated pipelines with S3 and EC2","Built metrics measurement tools for marketing campaign analysis","Estimated sales impact using Double Debiased Machine Learning","Prototyped real-time anomaly detection systems","Developed predictive models for inventory management"]},{"title":"Data Scientist Intern","company":"Amazon","duration":"May 2022 – July 2022","details":["Engineered models for slot selection and path optimization","Received Pre-Placement Offer for contributions in operational efficiency"]},{"title":"Business Analyst","company":"Tredence","duration":"June 2018 – April 2021","details":["Optimized inventory management reducing lead time by 40%","Designed scalable models for inventory recommendations","Developed anomaly detection software for data integrity"]}]	\N	\N	2025-07-15 10:20:47.273034	2025-07-15 10:20:47.273034	Interview	New Application	Pending	\N	10000.00	\N	{}	\N	\N	\N	\N	\N	\N		15 days
51	Johna	Doe	john.doea@example.com	Software Developer	1234567890	123 Main St		Computer Science	5 years			2025-07-16 18:45:02.320996	2025-07-16 18:45:02.320996	Screening	Recommended	Approved	Tech Corp	50000.00	60000.00	{}			\N	\N	\N	\N		15 days
87	RAJ	PANCHOLI	pancholiraj27@gmail.com	\N	+91-8769912780	[{"firstline":"Bangalore, India","city":"Bangalore","pincode":null,"district":null,"state":null,"country":"India"}]	\N	[]	[{"company":"ACKO","role":"UI-1 Engineer","duration":"SEP 2024 - Present","responsibilities":["Designed and implemented numerous Value-Added Service (VAS) widgets, including RTO details, vehicle information, PUC, Fastag, and challan widgets, taking ownership of most widgets in the company.","Developed scripts that generated over 5,000 dynamic pages with dynamic data.","Created a dynamic, responsive 'Quick Like' component, utilizing a single markup for both mobile and desktop versions while adapting to device-specific requirements.","Leveraged VAS widgets to drive significant business growth, resulting in an average of 250,000 new leads per month, as indicated by Amplitude and product manager insights."]},{"company":"ACKO","role":"SDE Intern","duration":"OCT 2023 - AUG 2024","responsibilities":["Developed the new career page from scratch using Next.js 13, managing the entire project over a 2-month period.","Integrated Strapi CMS, enabling non-developers to update text and images without technical assistance easily.","Achieved 100% desktop and 98% mobile performance, 100% SEO score, 100% best practices compliance.","Implemented both server-side and client-side rendering to optimize performance and user experience.","Collaborated on improving existing widgets, including health and life widgets, by enhancing code quality and UI design for a more polished user experience."]}]	\N	\N	2025-07-24 12:22:18.937522	2025-07-24 12:22:18.937522	Application	New Application	Pending	\N	\N	\N	{Javascript,"React JS 18","Next JS 14",HTML5,CSS3,Typescript,Python,Bootstrap,Tailwind,"Styled Components",Node,"REST API",Firebase,"Responsive UI","Functional Programming","Web Performance Optimization",Git,Github,Postman,Figma,Contentful,Strapi}	\N	\N	\N	/pancholiraj27	{}	{}	1753359721105-421936662.pdf	15 days
98	Tony	Rogers	admin123@ats.com	Captain America	8810307117	740 StViG St, Suite 500, San Jose, California, Germany, 951127	http://51.20.181.155:3000/api	edu	exp	summary	cv	2025-08-02 14:50:44.454301	2025-08-02 14:50:44.454301	Screening	New Application	Pending	A1 selectors	12000.00	24000.00	{react,postgres}	IIT Bhubaneswar	B.Tech	3.0	\N	\N	\N	https://www.linkedin.com/company/acmetech	30 days
42	Udayveer	Singh	veerukalpi2018@gmail.com	\N	93352 96725		\N	[{"institute":"AXIS INSTITUTE OF TECHNOLOGY & MANAGEMENT","degree":"INFORMATION TECHNOLOGY B.TECH","startDate":"July 2021","endDate":"July 2025","percentage":"68%"},{"institute":"DR. AMBEDKAR INTERCOLLEGE ATA","degree":"PCM INTERMEDIATE","startDate":"July 2019","endDate":"July 2020","percentage":"68%"},{"institute":"M.J.H INTERCOLLEGE ATA","degree":"HIGHSCHOOL","startDate":"July 2017","endDate":"July 2018","percentage":"85%"}]	[]	\N	\N	2025-07-10 16:42:55.167025	2025-07-10 16:42:55.167025	Interview	Initial Review	Pending	\N	\N	\N	{Java,Python,JavaScript,React,Git,"VS Code",MongoDb,MySql}	\N	\N	\N	\N	\N	\N		15 days
49	Swajal	Gupta	swajal.gupta.ug24@nsut.ac.in	\N	+91 6387953010		\N	[{"institution":"Netaji Subhash University of Technology, Delhi","degree":"Undergraduate (ECE with AIML)","startDate":"August 2024","endDate":"Present","cgpa":6.9},{"institution":"The Vivekanand School, Delhi","degree":"Class XII","startDate":"April 2021","endDate":"March 2022","percentage":82.2},{"institution":"Jawahar Navodaya Vidhyalaya, Rath","degree":"Class X","startDate":"September 2019","endDate":"March 2021","percentage":92}]	[{"title":"Resume Parser","description":"Built a Resume parser, CV scorer, and Job Description matching for Xbeeshire.com using Openai API","duration":null,"organization":"Xbeeshire.com"}]	\N	\N	2025-07-15 10:32:45.942335	2025-07-15 10:32:45.942335	Hired	New Application	Pending	\N	\N	\N	{}	\N	\N	\N	\N	\N	\N		15 days
52	Johnaa	Doe	john.doeaa@example.com	Software Developer	1234567890	123 Main St		Computer Science	5 years			2025-07-16 18:45:30.610213	2025-07-16 18:45:30.610213	Application	Screening Complete	Pending	Tech Corp	40000.00	70000.00	{}			\N	\N	\N	\N		15 days
92	MANASI	SINGH	manasi.singh0304@gmail.com	\N	+91 8369362821	[{"firstline":"Noida, India","city":"Noida","pincode":null,"district":null,"state":null,"country":"India"},{"firstline":"Bengaluru, India","city":"Bengaluru","pincode":null,"district":null,"state":null,"country":"India"},{"firstline":"Hyderabad","city":"Hyderabad","pincode":null,"district":null,"state":null,"country":null}]	\N	[{"institution":"Himalayan University","degree":"Bachelor of Arts: Economics","duration":null,"percentage":null,"cgpa":null},{"institution":"National Institute of Fashion Technology","degree":"B.Design: Hyderabad","duration":null,"percentage":null,"cgpa":null}]	[{"company":"Real11 Fantasy Sports","role":"Team Lead - Growth","duration":"03/2025 to Current","responsibilities":["Building real-money Rummy App from the ground up, responsible for everything except tech."]},{"company":"Octro Inc.","role":"Manager - Retention Marketing","duration":"09/2021 to 03/2025","responsibilities":["Worked at one of India's top gaming companies backed by Sequoia Capital, with a focus on growth and retention across core revenue driving games including Poker, Rummy, Teen Patti, and Slots.","Led a 6 member cross-functional team across Growth and LiveOps to drive monetisation and engagement across key game titles, working closely with product and analytics teams to design, run, and evaluate A/B tests.","Boosted D14 retention by 40% via segmented missions, personalised journeys & automated lifecycle campaigns.","Revived dormant VIPs, driving 15% MoM revenue via tailored offers & a dedicated VIP management team.","Increased payer conversion by 30% & Poker revenue by 38% via LiveOps, re-engagements & LTV experiments.","Led product development of an in-house CDP, delivered in 8 months to enable advanced player segmentation, automate CRM workflows & reduce tool costs by replacing MoEngage, Clevertap & other external platforms."]},{"company":"Stree","role":"Lead - Growth & Operations","duration":"11/2020 to 09/2021","responsibilities":["A women-led e-learning marketplace offering courses in lifestyle & fitness. Core team member who established the CS vertical, set up a CDP tool, designed onboarding journeys, & led community-building initiatives."]},{"company":"KocharTech","role":"Regional Head - Sales & CRM (South India)","duration":"11/2019 to 11/2020","responsibilities":["BPM firm specialising in customer experience solutions. Managed 23% of revenue, secured INR 4 Cr in new business in 3 months, & handled accounts like MPL, Swiggy, Samsung & ICICI, contributing to ARR of INR 15 Cr+."]},{"company":"Recov","role":"Founder and Growth Consultant","duration":"08/2017 to 10/2019","responsibilities":["B2B re-commerce platform dealing in second-hand electronics & furniture. Generated INR 4.5 Cr in GMV and consulted across multiple B2B e-commerce platforms, successfully generating INR 1 Cr+ in GMV."]},{"company":"Zerodha","role":"Assistant Manager","duration":"06/2016 to 08/2017","responsibilities":["Onboarded 11 B2B partners including Capital Via, opening 1,600+ accounts in under 10 months."]}]	\N	\N	2025-08-01 09:30:26.386395	2025-08-01 09:30:26.386395	Application	New Application	Pending	\N	\N	\N	{"customer lifecycle management","player journeys",LiveOps,"VIP programs",automation,monetisation,engagement,retention,"growth strategies","product development","player segmentation","CRM workflows"}	\N	\N	\N		two	two	1754040613691-676452693.pdf	15 days
45	rahul	tripathi	kprince2211@gmail.com	\N	8404841471		\N	[{"degree":"Bachelor of Technology with Honours","institute":"Indian Institute of Technology, Kharagpur","location":"Kharagpur, WB","graduationDate":"June 2019"}]	[{"company":"BADABUSINESS PVT LTD","role":"Sr.Product Data Analyst","location":"Delhi","duration":"Jan 2023 – Present","responsibilities":["Developed lead conversion models based on lead journey metrics, leading to 15% impact on conversion rates","Established 2-way Interactive OTT Platform, accommodating up to 5000 Participants In Digital Meetings, spiking an increase of 500% Training Coverage","Improved lead-to-visit ratio by 20% through targeted A/B testing, successfully optimizing product performance","Strategized content marketing in webinars, resulting in 19 lakh content downloads, contributing to 67% of total revenue","Introduced Add-ons like Game (Spin and Win), Phone Boosters, Polls, Optimized Referral Program, Increased User Stickiness from 18% to 26%","Revitalized homepage design, improved playstore rating, resulting in boosting DAU by 60% and MAU by 30%","Mapped User Journey for Complaint Management System, Reduced the Complaint Resolution TAT by 60%","Engineered automated BI dashboards and reporting tools with lookerstudio, Tableau, and Databricks, reducing manual reporting time by 80%"]},{"company":"1K KIRANA","role":"Product Data Analyst","location":"Gurugram, HR","duration":"April 2022 – Sept 2022","responsibilities":["Created 6+ real-time dashboards to keep track of supply chain for end-to-end delivery of 70000+ products","Strategised and Optimized 12+ KPIs for products ensuring better visibility and transparency in the pipeline","Documented 3 PRDs using Notion to translate business objectives and goals into technical requirements","Leveraged Mixpanel for Engagement metrics, boosting Product engagement by 7% & customer retention by 8%","Gathered requirements and assessed their impact ensuring minimum alteration in planned and desired product","Worked with tools like JIRA on Agile Model ensuring ticket prioritization and minimum product deviation","Developed and deployed predictive models for inventory optimization, increasing direct retail orders by 15% by aligning supply with demand"]},{"company":"CAPGEMINI","role":"Associate Consultant","location":"Bengaluru, KA","duration":"July 2019 - April 2022","responsibilities":["Developed framework to assess best Next Generation Anti-Virus, increased Anti-virus services to clients by 15%","Designed a end-to-end framework to set up lab for reverse engineering of Malware and its Analysis","Documented 3+ emerging technologies like Network Traffic Analysis, Operation Technology Security, Blockchain"]},{"company":"MBREADTH TECHNOLOGY","role":"Machine Learning Intern","location":"Kharagpur, WB","duration":"May 2018 – July 2018","responsibilities":["Extracted and normalized real-valued and binary facial parameters to predict facial expressions using facial images","Recruited the best performing and specialized neural networks to form an integrated neural network committee","Integrated and evaluated neural network dataset of 285 images with the precise prediction of 255 images"]}]	\N	\N	2025-07-11 14:05:50.782318	2025-07-11 14:05:50.782318	Screening	New Application	Approved	\N	\N	\N	{SQL,Python,Latex,R,YARA,VBA,Tensorflow,Pandas,Numpy,Sklearn,Matplotlib,"Adobe Photoshop",Balsamiq,"Advance MS-Excel","Google Data Studio",Whimsical,Tableau}	\N	\N	\N	\N	\N	\N		15 days
72	Ethan	Hunt		\N		[{"firstline":"","city":"","pincode":"","district":"","state":"","country":""}]	\N	[]	[]	\N	\N	2025-07-22 13:55:49.963342	2025-07-22 13:55:49.963342	Application	New Application	Pending	\N	\N	\N	{}	\N	\N	4.0					15 days
65	Jane	Smith	john.do13e@example.com	Software Developer								2025-07-21 15:07:49.810673	2025-07-21 15:07:49.810673	Interview	New Application	Pending		\N	\N	\N	\N	\N	4.0	\N	\N	\N		15 days
78	VISHWANATH	CHINDODI	vishwanath.chindodi@gmail.com	\N	+91-9663747354	[{"firstline":"Yelahanka, Bengaluru, KA","city":"Bengaluru","pincode":null,"district":"Yelahanka","state":"KA","country":"India"}]	\N	[{"institution":"Visveswaraya Technological University, India","degree":"Bachelor of Engineering","duration":"Aug 2008 – Aug 2012","percentage":"70%","cgpa":null}]	[{"company":"KIABI","role":"Data Scientist – IC (AI ML Dev)","duration":"Oct 2021 – Present","responsibilities":["Working as AI & ML Dev Manager to provide End to End AI Solutions in Fashion domain for India, Hong Kong & France teams","Researching and Developing AI Models for Image Processing, NLP, OCR Text Extraction, and Gen AI","Managing a team of 4 with Work Assignment, Task Review, Scrum, Guidance, and Feedback","Developed OCR and LLM models with RAG framework for PDF analysis and Chatbot responses","Created Gemini Gen AI model for invoice text extraction and table filling","Built Video Processing Model for Headcount detection","Developed RFR Model for purchase order delay prediction","Created Power BI and Tableau dashboards for organizational metrics"]},{"company":"AB-InBev","role":"Data Scientist","duration":"Nov 2019 – Sept 2021","responsibilities":["Worked on Data Science & Data Analysis in People’s Domain","Developed NLP skills extraction models using TF-IDF and Word2Vec","Worked on Image Processing, Text Extraction, and Hierarchical Bayes Algorithm","Led teams and projects, managed stakeholders, delegated tasks, and set deadlines"]},{"company":"Samsung - HCS","role":"Data Analyst","duration":"Jan 2018 – Oct 2019","responsibilities":["Data Analysis, Data Science, Data Modeling and Mart Designing","Developed a PoC for Airline Price Estimation based on Customer Analysis"]},{"company":"Infosys Ltd","role":"Senior System Engineer","duration":"Aug 2013 – Dec 2017","responsibilities":["Worked on Data Analytics, DWH Projects, ETL, DB & Reporting for clients in UK & US","Automation of Data Projects and Big Data Internal Certification"]},{"company":"PurpleFrame Technologies Pt. Ltd.","role":"Software Engineer - Intern","duration":"Sept 2012 – June 2013","responsibilities":null}]	\N	\N	2025-07-24 10:04:15.193677	2025-07-24 10:04:15.193677	Application	New Application	Pending	\N	\N	\N	{"Data Analytics","Machine Learning","Deep Learning","Data Visualizations","Data Design","Data Modeling","Big Data",ETL,DWH,Reporting,"Gen AI",Statistics,Python,R,SQL,"GCP Cloud","Gemini AI",Llama,NLP,NLTK,TF-IDF,Word2Vec,CV2,Pytesseract,LLM,TensorFlow,PyTorch,scikit-learn,CART,Regression,"Neural Networks","Image & Video Processing",Anaconda,Streamlit,Tableau,"Power BI","Qlik Sense",Azure,JIRA,"VS Code",Agile,Communication,"Technical Documentation","Analytical Problem-Solving",Creative,"Team Collaboration",Adaptability,"Project Management",Prioritization}	\N	\N	\N	www.linkedin.com/in/vishwanath-chindodi/	two	two	1753351412006-452379354.pdf	15 days
64	John	Doe	john.do12e@example.com		-903	123 Elm St, NY, USA	photo_url.jpg	BSc Computer Science	5 years	Experienced full-stack developer.	cover_letter_johndoe.pdf	2025-07-21 15:07:49.804982	2025-07-21 15:07:49.804982	Application	New Application	Pending	TechCorp	\N	\N	\N	\N	\N	\N	\N	\N	\N		15 days
47	Yash	Raj Singh	yashbhadauria@gmail.com	\N	+91 9981958447		\N	[{"institute":"VIT Vellore","location":"Vellore, India","degree":"B.Tech, Electrical and Electronics","startYear":2016,"endYear":2020,"cgpa":8.01},{"institute":"DPS, Mathura Road","location":"Delhi, India","degree":"GPA","score":91,"year":2015}]	[{"company":"The Chubb Corporation","location":"Bangalore, India","title":"Senior Data Scientist","startDate":"Oct 2024","endDate":"Present","responsibilities":["Developed and implemented testing frameworks for LLMs in underwriting, enhancing accuracy, bias detection, and robustness, resulting in a 30% reduction in processing errors and improved stakeholder trust."]},{"company":"Apexon","location":"Bangalore, India","title":"Machine Learning Engineer","startDate":"Sept 2023","endDate":"Sept 2024","responsibilities":["Led the AI Domain Name Recommendation Engine project for Identity Digital that improved website domain naming yield by 100% through monthly keyword trend identification.","Implemented monthly keyword trend identification, reducing dependence on TF-IDF based search and leading to 100% increase in industry relevant domain name suggestions.","Implemented clustering algorithms to identify keyword trends.","Used gradient descent based hyperparameter tuning to improve the accuracy of the top level domain name recommendation by 87%.","Deployed quantized embeddings models focused on increasing evaluation accuracy and reducing inference latency for semantic suggestions.","Leveraged transformer models to generate 30% more creative suggestions validated against existing rule based search results.","Enhanced system design to reduce average model latency from 5 seconds to 1.8 seconds."]},{"company":"Brysk/Niflr","location":"Bangalore, India","title":"Machine Learning Engineer","startDate":"Dec 2022","endDate":"Sept 2023","responsibilities":["Built a hand pose estimation model for SKUs (Stock Keeping Units) tracking, reducing incorrect cart additions by 10%.","Designed and implemented a cloud-based backend using Node.js for communication with microservices, facilitating order creation, video labeling, and ticket clearance.","Authored code for managing IoT devices including QR scanners, cameras, and weight sensors on custom Masterboards and Raspberry Pi platforms."]},{"company":"Tata Consultancy Services","location":"Bangalore, India","title":"Systems Engineer","startDate":"Oct 2020","endDate":"Dec 2022","responsibilities":["Built an end-to-end workspace booking management system, improving office resource management."]}]	\N	\N	2025-07-15 10:20:46.09283	2025-07-15 10:20:46.09283	Application	New Application	Approved	\N	\N	\N	{}	\N	\N	\N	\N	\N	\N		15 days
77	arvind	gupta	arvind.gupta81@gmail.com	\N	9873071299	[{"firstline":"FF,A76, Emaar Emerald Hills, Sector 65 Gurgaon122018","city":"Gurgaon","pincode":"122018","district":null,"state":null,"country":"India"}]	\N	[{"institution":"MICA","degree":"Advanced Certificate in Digital Marketing","duration":"June 2021 - May 2022","percentage":null,"cgpa":null},{"institution":"SACAC","degree":"Post Graduate Diploma- Advertising and Public Relations","duration":"2007-2008","percentage":null,"cgpa":null},{"institution":"Ranchi University","degree":"Bachelor of Arts Honors in Humanities and Economics","duration":"2001-2004","percentage":null,"cgpa":null}]	[{"company":"Zupee.com","role":"Associate Director – Brand Marketing","duration":"Apr 2022 – Present","responsibilities":["Spearheaded brand strategy and marketing for one of India’s fastest-growing gaming platforms, overseeing brand positioning, and messaging across touch points","Led multi-channel brand campaigns (offline + digital), ensuring creative excellence and build awareness, drive customer acquisition, and improve retention—aligned to business and revenue goals","Managed ₹100 Cr+ in annual advertising budget, delivering ROI-focused initiatives and brand-building programs","Collaborated with creative and media agencies to develop breakthrough brand narratives that drove awareness, user acquisition, and retention","Built and led a high-performing team, fostering creativity, ownership, and cross-functional collaboration","Leveraged market insights, consumer research, and media attribution models to guide brand strategy and optimize campaign effectiveness"]},{"company":"Mindshare (WPP)","role":"Senior Director – Brand & Media Strategy","duration":"Oct 2021 – Apr 2022","responsibilities":["Directed strategic brand and media planning for Muthoot Finance and Pristyn Care, managing over ₹170 Cr in annual brand spend","Partnered with clients on brand storytelling (Sunhery Soch) and campaign architecture, ensuring alignment with long-term brand goals","Delivered post-campaign analysis and strategic insights to CXOs to inform future brand investment and positioning"]},{"company":"Publicis Media","role":"Business Director – Brand Strategy & Client Leadership","duration":"Mar 2017 – Oct 2021","responsibilities":["Led brand planning and marketing strategy for Hero MotoCorp and Dabur (Health & Skincare), driving brand innovation and consumer relevance","Launched BS6 campaign with a technology-led creative approach that resulted in a significant increase in brand preference and sales","Oversaw content partnerships and brand integrations to create culturally resonant communication across traditional and digital channels"]},{"company":"Omnicom Media Group","role":"Associate Director – Brand Planning & Media","duration":"Jan 2015 – Mar 2017","responsibilities":["Developed and executed integrated brand campaigns for HP, including X360, Spectre and Star Wars series launches","Managed end-to-end media and communication planning while driving synergies between creative development and media strategy","Media buying activities, negotiating rates and placements with media vendors to maximize ROI and ensure cost-effectiveness"]},{"company":"Zenith Optimedia","role":"Group Head","duration":"2014–2015","responsibilities":["Led brand media strategy for OLX"]},{"company":"Havas Media","role":"Group Head","duration":"2013–2014","responsibilities":["Strategic advisor for Hyundai & VLCC on brand planning and media execution"]},{"company":"Allied Media","role":"Media Group Head","duration":"2009–2013","responsibilities":["Managed communication strategy for Panasonic and Nomarks"]},{"company":"MPG","role":"Media Planning Executive","duration":"2008–2009","responsibilities":["Supported performance reporting and campaign analysis"]}]	\N	\N	2025-07-24 10:03:53.588905	2025-07-24 10:03:53.588905	Interview	New Application	Pending	\N	\N	\N	{"brand strategy","marketing campaigns","creative development","media planning","brand storytelling","campaign architecture","media buying","content partnerships","performance reporting","customer engagement","market insights","media attribution","brand positioning"}	\N	\N	\N	https://arvind-gupta	two	two	1753351411221-871191529.pdf	15 days
94	Maninder	Singh	imaninder4@gmail.com	Data Scientist	8168801970	[{"firstline":null,"city":null,"pincode":null,"district":null,"state":null,"country":null}]	\N	[{"institution":"PUNJAB TECHNICAL UNIVERSITY","degree":"Bachelor of Engineering, ECE","duration":"Jul 2014 to Jun 2018","percentage":null,"cgpa":null},{"institution":"Shree Ram Ideal School, CBSE","degree":null,"duration":"Mar 2014","percentage":null,"cgpa":null}]	[{"company":"ZZAZZ","role":"Senior Data Analyst","duration":"Apr 2024 to Present","responsibilities":["Improved completion rate by 25% in 6 weeks, leading to higher user engagement and conversions, by generating publisher-specific recommendations through analysis of session duration, bounce rate, and content format trends using Databricks and MongoDB.","Decreased bot readers from 22% to 9% in 2 months by refining bot detection through user-agent analysis to detect behavior anomalies and ensured accurate engagement metrics using Python and SQL queries and data manipulation techniques.","Reduced weekly reporting time by 80% by proactively creating automated dashboards and writing SQL queries to replace manual Excel reports, using Databricks and Metabase.","Improved content strategy, with data-driven segmentation and monetization strategies, by building session-level engagement models using statistical frameworks and modelling techniques to compute interaction scores from scroll depth, session duration, and bounce rate with SQL, Python and Databricks.","Partnered with stakeholders like product managers, data engineering team, and frontend developers to define and validate event tracking instrumentation schemas; leveraged Python-based QA scripts, DigitalOcean to support continuous improvement in data accuracy and systems monitoring.","Recognized by product and content teams for effectively translating complex event datasets into clear, actionable business use-cases and metrics, significantly improving stakeholder decision-making."]},{"company":"SHAIP.AI DATA","role":"Data Analyst","duration":"Sep 2021 to Feb 2024","responsibilities":["Increased team productivity by 20% in 3 months from prior performance levels to revised targets by implementing templated guidelines, auto-checks for missing data, and UI enhancements using QA workflows and Taskmonk platform.","Improved accuracy from 85% to 95% in 2 months of data classification by conducting audits on NLP-labeled datasets, identifying quality gaps, optimizing labeling protocols to ensure clean, high-quality outputs and applying behavioral and economics-driven analysis to drive reviewer alignment on edge cases using Dataloop.","Reduced rework rates from 22% to 8% in 6 weeks by collaborating with cross-functional teams to co-develop clearer annotation rules and implement structured feedback cycles using Excel, Jira, and an internal annotation platform."]},{"company":"PARALLEL DOTS","role":"Data Associate","duration":"Jan 2021 to Aug 2021","responsibilities":["Delivered clean, high-quality labeled datasets with 96% precision in 2 months by leading panel-based QA initiatives across FMCG clients using statistical validation checks and expert-aligned quality thresholds within an internal annotation platform.","Established annotator performance to 92% accuracy, up from inconsistent onboarding outcomes, in 4 weeks by designing training programs aligned with project-specific goals and quantitative benchmarks.","Trained incoming data associates to achieve regulatory compliance from 90% to 98% in 3 weeks by documenting responsibilities, sharing best practices, and implementing repeatable QA processes."]}]	\N	\N	2025-08-01 09:30:50.834013	2025-08-01 09:30:50.834013	Interview	Screening Complete	Pending	\N	40000.00	\N	{SQL,Excel,Python,"Google Analytics",Metabase,Tableau,"Power BI",AWS,DigitalOcean,Databricks,MySQL,PostgreSQL,MongoDB}	\N	\N	5.0	linkedin.com/in/maninder-singh-ds/	two	two	1754040614044-735079004.pdf	15 days
80	Punit	Baheti	Punitbaheti2@gmail.com	\N	+91-8981272512	[{"firstline":"152/6, Hardutt Rai Chamaria Road, Shiva Apartment Howrah 711101","city":"Howrah","pincode":"711101","district":"Howrah","state":null,"country":"India"}]	\N	[{"institution":"ICAI","degree":"CA Final","duration":"Dec 2021","percentage":"61%","cgpa":null},{"institution":"ICAI","degree":"CA Intermediate","duration":"Nov 2018","percentage":"74%","cgpa":null},{"institution":"ICAI","degree":"CPT","duration":"Jun 2017","percentage":"88%","cgpa":null},{"institution":"St. Xavier’s College – Kolkata","degree":"B.COM (H)","duration":"Jul 2020","percentage":null,"cgpa":"6.93"},{"institution":"St. Helen’s School, Howrah","degree":"Class-XII, ISC","duration":"Mar 2017","percentage":"91%","cgpa":null},{"institution":"St. John’s High School, Howrah","degree":"Class-X, ICSE","duration":"Mar 2015","percentage":"85%","cgpa":null}]	[{"company":"Infifresh Foods Private Limited (Captain Fresh)","role":"Manager: FP&A","duration":"Jun 2023 - Present","responsibilities":["Preparation of MIS Reports such as Monthly Performance Report, Key Financial Metrics and reporting of exceptional items to the top management for Asia and North America Region.","Conduct detailed financial analysis to support strategic initiatives, including profitability analysis, cost control and investment evaluations.","Prepared comprehensive Board meeting decks that provide actionable insights and strategic recommendation, aligning with the company’s financial objectives and performance metrics.","Conducted detailed variance analysis and financial forecasting, highlighting key trends and variances to support strategic decision-making.","Prepare monthly, quarterly and annual financial reports, providing insights into financial performance and recommendations for improvement.","Handle complex ad hoc requests with a short turnaround time and supplement such requests with appropriate analysis and comments to support decision making.","Collaborate with department heads and business units to understand their business needs and provide financial support and guidance.","Monthly reporting to banks and investors (Key Financial Metrics and Covenants).","Participated in the development of the company's standard operating procedures.","Understanding and Analyzing revenue sharing models for both Direct and Indirect Export for the Asia Region.","Ownership of Expense forecast for the business group by using trend analysis and KPI’s.","Monthly Review of Performance by Business Head related to EBITDA at city and Specie Level."]},{"company":"Jindal Steel and Power Limited (JSPL)","role":"AM: FP&A","duration":"May 2022 - May 2023","responsibilities":["Preparation of MIS reports such as TOC files, P&L variance, monthly performance reports, Capex MIS, fever reports & Ageing analysis, Cash Blockage, EBITDA reconciliation, Cost Analysis, Plant wise cost variance and Fixed cost.","Demonstration of 17 weeks Cash Flow by preparing next 4 weeks Forecast & analyzing last 13 weeks trend of Cash Flows.","Managing the working capital of the plant by analyzing its various components and reviewing and updating the norms for Cash Blockage.","Analyzing SBU wise EBITDA on Weekly Basis and analyzing its trend and performing analytics on KPIs for business units on a monthly and quarterly basis.","Assisted in Annual Business Plan of Plant and analyzing areas for improvement.","Worked on automation projects for daily operational cash flow report.","Reconciliation of EBITDA and MIS Cash flows with the Books of Accounts and engage and manage adhocs from business partners.","Engage and manage adhocs from business partners.","Performing Financial Modelling of Capex plan for expansion project at plant locations.","Responsible for driving meetings and discussions with stakeholders/business partners independently."]},{"company":"Haribhakti & Co LLP (CA Firm)","role":"Article Trainee (Assurance Service)","duration":"Apr 2019 - Mar 2022","responsibilities":["Conducted Statutory Audits, Limited Reviews, Tax Audits, Stock Audits and various Certification works.","Key areas handled in audit pertain to Valuations & Treatment of Loans and Investment, BRS, Borrowings, Operating Lease, Preparation of CARO Report, Finance Lease, Segment Reporting, Tax Computation, Consolidation (Ind AS), First time adoption of Ind AS, compliance of Schedule III, Vouching & Verification, Derivative Accounting."]}]	\N	\N	2025-07-24 10:07:21.600979	2025-07-24 10:07:21.600979	Interview	Recommended	Pending	\N	\N	\N	{"Financial analysis","Budgeting and forecasting","Management reporting","Variance analysis","Financial modeling","Cost control","Strategic planning","Stakeholder management"}	\N	\N	\N		two	two	1753351604412-779711970.pdf	15 days
88	Akash	Sonowal	work.akashsonowal@gmail.com	\N	+91-8812054820 / 8638450690	[{"firstline":"Bengaluru","city":"Bengaluru","pincode":null,"district":null,"state":null,"country":"India"},{"firstline":"Mumbai","city":"Mumbai","pincode":null,"district":null,"state":null,"country":"India"},{"firstline":"Remote","city":null,"pincode":null,"district":null,"state":null,"country":null}]	\N	[{"institution":"IIT Kanpur","degree":"MTech","duration":"2020-2022","percentage":null,"cgpa":null},{"institution":"IIT Guwahati","degree":"BTech","duration":"2016-2020","percentage":null,"cgpa":null}]	[{"company":"NoBroker.com","role":"Data Scientist II","duration":"Oct 2024 - Present","responsibilities":["Built real-time multilingual voicebots using STT, LLM, and TTS in a high-performance streaming WebSocket framework, with human-like interactivity and dynamic tool calling features","Finetuned Llama 3.2 (3B) on multi-turn conversational data using SFT with LoRA, achieving cross-entropy of 0.19; finetuned xTTS multilingual (Hindi and English) model to attain 3.87 MOS and 0.25 CER","Deployed Triton based streaming xTTS model server on GKE cluster (2 GCP L4 nodes) for serving 360 RPM at <250 ms TTFB latency and RTF of 0.46","Reduced call center operational costs by ₹40k/month and boosted Convozen AI’s revenue by ₹25+ lakhs/month with onboarding of 5+ clients"]},{"company":"HERE Technologies","role":"Senior AI/ML Engineer","duration":"Mar 2024 - Oct 2024","responsibilities":["Built a RAG system using vector databases (Chroma) and LLMs for real-time context-aware search and response generation over 25k+ internal documents","Implemented a change data capture based ingestion framework with Amazon SQS, EFS and custom Langchain dispatchers, optimizing vector database refresh time to ~30 mins and achieving retrieval accuracy of 84%","Deployed vLLM based Llama 3.1 (4bit, 7B) server on AWS ECS cluster (5 EC2 nodes) for serving 1800 RPM at <3 secs latency","Improved operational efficiency by reducing 4 hrs/day of Technical Support Team in resolving 50+ daily tickets"]},{"company":"MPHASIS","role":"Data Scientist, Applied Research","duration":"July 2022 - Mar 2024","responsibilities":["Implemented a hybrid Autoencoder with GAN model for high fidelity synthetic tabular data generation, achieving > 95% on statistical tests and strong privacy scores","Developed PoC for sparse binary segmentation of 2D CT scans using SwinMAE + SwinUnet, achieving a 5% test dice loss","Developed PoC for generating synthetic chest X-ray images via a fine-tuned diffuseVAE guided by MoCo, attaining ~2% contrastive MSE","Drove GTM leads and boosted AWS Sagemaker marketplace revenue by 44% with ML based PoC applications"]}]	\N	\N	2025-07-24 12:22:39.576728	2025-07-24 12:22:39.576728	Interview	Screening Complete	Pending	\N	\N	\N	{Python,PyTorch,Tensorflow,Huggingface,Scikit-learn,AWS,Azure,GCP,Flask,Docker,Kubernetes,ElasticSearch,Mongo,Airbyte,Airflow,MySQL,Streamlit,Gradio,Bash,SQL,NLP,"Computer Vision",Graphs,Speech,"Time Series",Tabular,"Generative AI","Recommender Systems",Classification,Regression,Forecasting,Supervised,Unsupervised,Self-Supervised,Algorithms,"Data Structures"}	\N	\N	4.0	linkedin.com/in/akashsonowal	two	two	1753359722093-178201121.pdf	15 days
93	M.	Lakshmi Prasanna	mlakshmiprasanna84@gmail.com	\N	+91 8328527384	[{"firstline":"Bengaluru, INDIA","city":"Bengaluru","pincode":null,"district":null,"state":"Karnataka","country":"India"}]	\N	[{"institution":"Annamacharya institute of technology and science boinapallli rajampet","degree":"MBA/PGDM - Finance","duration":"2022","percentage":null,"cgpa":"8/10"},{"institution":"Yogi Vemana University, Kadapa","degree":"B.Com - Commerce","duration":"2020","percentage":null,"cgpa":null},{"institution":"Andhra Pradesh","degree":"12th","duration":"2017","percentage":"91%","cgpa":null},{"institution":"Andhra Pradesh","degree":"10th","duration":"2015","percentage":"75%","cgpa":null}]	[{"company":"Ats share brokers Pvt Ltd","role":"Business Development Executive","duration":"12/2023 - 04/2025","responsibilities":["Lead Generation: Identify potential clients through cold calls, emails, networking, and online platforms.","Client Relationship Management: Build and maintain strong relationships with new and existing clients.","Market Research: Analyze market trends and competitors to find new business opportunities.","Sales Strategy: Develop and implement effective sales strategies to achieve targets.","Presentations & Pitches: Prepare and deliver business proposals and presentations to potential clients.","Follow-ups: Regular follow-ups with prospects to close deals.","CRM Management: Maintain updated records of client interactions in CRM tools.","Collaboration: Work with marketing, product, and sales teams for client-focused solutions.","Financial services: investment handling and finance sectors."]}]	\N	\N	2025-08-01 09:30:37.643671	2025-08-01 09:30:37.643671	Application	New Application	Pending	\N	\N	\N	{"Business Development",Sales,"Customer Relationship Management CRM Software","Stock Management",Investment,"Outlook Configuration","KYC Operations","Content Moderation","Lead Generation","Revenue Generation","Business Growth"}	\N	\N	\N	https://www.linkedin.com/in/m-lakshmi-prasanna-853669277?	two	three	1754040613867-553350166.pdf	30 days
44	tripathi	rahul	kaminipal428@gmail.com	\N	8007397338		\N	[{"institute":"Pune Institute of Business Management (PIBM)","qualification":"PGDM","year":2017},{"institute":"Chhatrapati Shahu Ji Maharaj University (C.S.J.M)","qualification":"B.Sc.","year":2014},{"institute":"UP Board","qualification":"12th (PCM)","year":2009},{"institute":"UP Board","qualification":"10th","year":2007}]	[{"organization":"Allied Boston Consultants India Pvt. Ltd.","role":"CRM Executive","startDate":"July 2024","endDate":"Present","location":"Sector 132 Noida (U.P)"},{"organization":"Franchise India Pvt. Ltd.","role":"Manager- Channel support","startDate":"May 2022","endDate":"September 2023","location":"Surajkund Faridabad (Haryana)"},{"organization":"SK Engineers","role":"Executive - IT Inside Sales","startDate":"March 2020","endDate":"May 2022","location":"Delhi"},{"organization":"Adecco India Pvt. Ltd.","role":"Executive - Inside Sales","startDate":"Feb 2019","endDate":"March 2020","location":"Pune"}]	\N	\N	2025-07-11 13:58:48.229175	2025-07-11 13:58:48.229175	Interview	New Application	Approved	\N	\N	\N	{"Power BI Dashboard & Report Development","Advanced Excel & Google Sheets","Tendering & Bidding (GeM, CPWD, PSU, Private Sector)","CRM Management & Sales Operations Support","Inside Sales & Lead Generation","Project Coordination & Stakeholder Communication","Negotiation & Client Relationship Management","Data Analysis & Visualization","Process Improvement & Documentation"}	\N	\N	\N	\N	\N	\N		15 days
43	Atul	Kumar	doodleforcode@gmail.com	\N	6393815787		\N	[{"institute":"National Institute of Technology, Kurukshetra","degree":"B.Tech in Computer Engineering","startDate":"Nov 2021","endDate":"Jun 2025 (Expected)","cgpa":8.5},{"institute":"Little Flower School, Gorakhpur, UttarPradesh","qualification":"12th, PCM(ISC)","percentage":86.6},{"institute":"Little Flower School, Gorakhpur, UttarPradesh","qualification":"10th(ICSE)","percentage":92.67}]	[{"company":"TMRW(Aditya Birla Fashion and Retail Limited)","role":"Software Engineering Intern","duration":"Jan 2025 - Present","responsibilities":["Maintained and optimized the Catalogue Management System built on Next.js, ensuring system reliability and achieving a 10% improvement in loading speed, leading to faster access to catalog information for end-users.","Rectified 15+ critical production bugs on Nautinati.com and Nobero.com using Shopify Liquid, HTML, CSS, JavaScript, and TailwindCSS, resulting in a 20% decrease in user-reported website issues over three months.","Spearheaded A/B testing to new website features on Nobero.com using JavaScript and TailwindCSS, directly increasing user engagement by 15% and improving conversion rates by 10% within one month.","Developed a comprehensive download app campaign growth hack, resulting in a 20% increase in app downloads and a significant improvement in customer retention rates."]}]	\N	\N	2025-07-11 13:41:53.529928	2025-07-11 13:41:53.529928	Hired	New Application	Pending	\N	\N	\N	{}	\N	\N	\N	\N	\N	\N		15 days
95	Test	Candidate	candidate@gmail.com	Node js developer	7042094905	123 mirja mandi kalpi		test education				2025-08-01 14:50:11.897153	2025-08-01 14:50:11.897153	Application	New Application	Pending		0.00	0.00	{}			0.0	\N	\N	\N	www.resumelink.com	30 days
79	KUNAL		kr.cakunal@hotmail.com	\N	9873198595	[{"firstline":"Delhi 110042","city":"Delhi","pincode":"110042","district":null,"state":"Delhi","country":"India"}]	\N	[{"institution":"INSTITUTE OF CHARTERED ACCOUNTANTS - NEW DELHI","degree":"CA","duration":null,"percentage":null,"cgpa":null},{"institution":"DELHI UNIVERSITY - NEW DELHI","degree":"B.COM","duration":"Passed in June 2019","percentage":null,"cgpa":null},{"institution":"TITIKSHA PUBLIC SCHOOL - NEW DELHI","degree":"XII","duration":"Passed in 2014","percentage":null,"cgpa":null}]	[{"company":"UNIVO EDUCATION PVT. LTD.","role":"Manager FP&A","duration":"AUG’23 - Till Present","responsibilities":["Analyzed financial data, including budgets, forecasts, and financial statements, to provide insights and support decision-making processes.","Developed financial models and performed variance analysis to identify trends and areas of improvement.","Participated in the budgeting and forecasting process, collaborating with cross-functional teams to ensure accuracy and alignment with business objectives.","Prepared management reports and presentations to communicate financial performance, risks, and opportunities to senior management.","Ensured revenue & expenses completeness for the period.","Monitored IT assets as a cost saving measure.","Monitored marketing expenses daily to minimize wastage of funds."]},{"company":"ICICI BANK LTD.","role":"Deputy Manager Operations (Taxation)","duration":"Oct’22 – July’23","responsibilities":["Working related to TDS on Interest U/s 194A & 195 of Income Tax Act, 1961.","Filling quarterly TDS returns.","Remittance of TDS to Govt.","Solving queries related to wrong TDS deduction.","Replying to Income Tax notices.","Refund & recovery of TDS from customers using Finacle."]},{"company":"Jain chindalia & Co.","role":"Article trainee","duration":"Aug’17 – Dec’20","responsibilities":["End to End preparation of financial statements of various manufacturing companies from scratch.","Filling of GST returns, Tax audits and completing audit for the companies.","In depth analysis about revenue and expenses.","Preparation of Financial models for Pvt companies requiring funds from banks.","Variance analysis.","CMA data preparation.","Filling of Income tax returns."]}]	\N	\N	2025-07-24 10:07:00.544848	2025-07-24 10:07:00.544848	Interview	New Application	Pending	\N	\N	\N	{Leadership,"Handle assignments",Teamwork,"Pressure Handling","Time Management","Client Relationships",Research,Problem-solving}	\N	\N	\N		two	two	1753351602613-772438929.pdf	15 days
96	SAURABH	KUMAR	sk9709844607@gmail.com	\N	7004427340	[{"firstline":"PATEL CHOWK, WARD NO-11, FORBESGANJ ARARIA, BIHAR-854318","city":"Forbesganj","pincode":"854318","district":"Araria","state":"Bihar","country":"India"}]	\N	[{"institution":"B.S.E.B. PATNA","degree":"Matric","duration":"2014","percentage":"43.8","cgpa":null},{"institution":"B.S.E.B. PATNA","degree":"Intermediate","duration":"2016","percentage":"46.6","cgpa":null},{"institution":"B.N.M.U. Madhepura","degree":"Graduation","duration":"2023","percentage":"61","cgpa":null}]	[{"company":"Samsung India Electronic","role":"T.S.E.","duration":"2016-2018","responsibilities":["Ready Stock Working And Sell The Product In Market Handling 1 Distributer"]},{"company":"R.S.P.L. LTD–HCD","role":"Sales Incharge","duration":"January 2018 - April 2019","responsibilities":["Handled 5 Distributors","Created 2 Distributors","Managed Primary And Secondary Sales"]},{"company":"SHANTINATH DETERGENT PVT LTD (SAFED DETERGENT)","role":"Territory Sales Officer","duration":"June 2019 - March 2021","responsibilities":["Handled 2 Distributors","Managed 1 Super Stockist","Supervised 10 Sub Distributors","Created 7 Sub Distributors","Handled Primary And Secondary Sales"]},{"company":"R.S.P.L. H.C.D.","role":"Sales Officer","duration":"March 2021 - February 2023","responsibilities":["Handled 1 Super Stockist","Managed 3 Distributors","Supervised 10 Sub Distributors","Created 2 Distributors","Created 7 Sub Distributors","Worked in 2 Districts (ARARIA, PURNIA)","Managed 4 Man Power"]},{"company":"PATANJALI FOOD LTD","role":"Sales Officer","duration":"March 2024 - Present","responsibilities":["Handled 2 Super Stockists","Managed 8 Distributors","Supervised 18 Sub Distributors","Created 11 Sub Distributors","Worked in 4 Districts (ARARIA, PURNIA, KATIHAR, KISHANGANJ)","Managed 7 Man Power"]}]	\N	\N	2025-08-01 17:40:19.803484	2025-08-01 17:40:19.803484	Application	New Application	Pending	\N	\N	\N	{"Good Interactive skill",Self-confidence,"Willingness to travel",Punctuality,"Basic computer knowledge","Internet surfing",Traveling,"Bike riding"}	\N	\N	\N		three	three	1754070005717-619929784.pdf	15 days
89	Yash	Khandelwal	yashkhandelwal730@gmail.com	\N	9876543210	[{"firstline":null,"city":"Bengaluru","pincode":null,"district":null,"state":null,"country":null}]	\N	[{"institution":"ICAI","degree":"CA-Final","duration":"2022","percentage":54.5,"cgpa":null},{"institution":"University of Rajasthan","degree":"Bachelor of Commerce (B.Com)","duration":"2017-2020","percentage":73.28,"cgpa":null},{"institution":"CBSE","degree":"Class XII","duration":"2016-2017","percentage":88.4,"cgpa":null}]	[{"company":"Myntra Jabong India Pvt. Ltd.","role":"Manager FP&A and Business Finance","duration":"October 2022 to Present","responsibilities":["Management reporting of P&L (MIS) at various levels on a monthly basis and review with Business.","Forecasting weekly Business P&L with high accuracy, identifying Risks and Opportunities.","Aligning Month operating plan (MOP) with key performance metrics and ROI.","Facilitating timely books closure, reviewing and reconciling financial reports.","Presenting financial performance to CFO and Leadership.","Preparing decks for SLT Reviews and performance analysis.","Supporting strategic decision making via P&L scenario analysis.","Conducting GM ROI analysis, evaluating GMV growth and vendor discounts.","Forecasting, analyzing, and reporting targets for Offline Retail Business.","Reporting business KPIs and entity level P&L for tax and compliance.","Projecting 12M rolling P&L and preparing annual and long-range plans.","Reporting to the Board on company performance and P&L.","Participating in automation and data dashboard development using Power BI."]},{"company":"Finance Lookup Advisors","role":"Finance Intern","duration":"January 2022 to July 2022","responsibilities":["Finalization of financial statements and business valuation projections.","Conducting business valuations using DCF and NAV methods.","Preparing valuation reports for Business, Inventory, and Fixed Assets.","Researching company environment, competitors, growth, and risk factors."]},{"company":"Badaya & Company (Chartered Accountants), Jaipur","role":"Articleship","duration":"2018 to 2021","responsibilities":["Performing statutory, tax, internal, and stock audits across various industries.","Managing work efficiently and training juniors.","Assisting in Income Tax proceedings, ITAT submissions, and tax filing."]}]	\N	\N	2025-07-24 13:05:19.526826	2025-07-24 13:05:19.526826	Interview	Recommended	Approved	\N	440.00	300000.00	{"Financial planning and analysis (FP&A)","Business finance and reporting","Accounting standards","Financial modeling","Forecasting and scenario analysis","Power BI dashboards","Data reconciliation","Management reporting"}	\N	\N	\N	linkedin.com/in/ca-yash-khandelwal	two	two	1753362303033-571367988.pdf	15 days
99	HIMANSHU	MEHTA	HimanShu.mehta090@gmail.com	\N	+91-8800594185	[{"firstline":"Bengaluru, Karnataka","city":"Bengaluru","pincode":null,"district":null,"state":"Karnataka","country":"India"}]	\N	[{"institution":"National Institute of Technology, Kurukshetra","degree":"B.Tech","duration":"2009-2013","percentage":null,"cgpa":8.1}]	[{"company":"BeepKart","role":"Director of Marketing/Growth","duration":"Apr 2022 - Oct 2024","responsibilities":["Reduced CAC by 57% (₹7K to ₹3K) and grew MAU by 600% (200K to 1.3M).","Scaled monthly deliveries from 300 to 1,000, improving the NPS score with an AOV of ₹90,000.","Designed and executed a ₹3 Cr ATL/BTL & digital branding campaign, delivering a 390% surge in organic search volume (10K to 49K).","Enhanced customer satisfaction through an innovative branded store concept, leveraging insights from 80 consumer interviews.","Created a comprehensive brand playbook, defining TG, USPs, and key triggers/barriers.","Managed a ₹15 Cr marketing budget, contributing to ARR growth of $13M with 50% organic delivery share."]},{"company":"GoodWorker","role":"Growth Architect Lead/Head","duration":"Jun 2020 - Apr 2022","responsibilities":["Achieved ₹15 Cr ARR.","Directed multi-channel campaigns featured in 250+ publications, enhancing SEO and video marketing reach.","Crafted ideal customer personas and behavior insights for rural and semi-urban audiences, tailoring content strategies by visiting 7 key states like UP, Bihar, WB, Jharkhand, Odisha, etc.","Aligned brand efforts with key influencers, government bodies, and NGOs to strengthen equity. Did more than 20 Cr+ ATL/BTL activations across states.","Boosted rural customer engagement by identifying and addressing digital behavior patterns in Tier-3/4 markets."]},{"company":"Rebel Foods","role":"Growth Manager Lead","duration":"Feb 2019 - Jun 2020","responsibilities":["Increased repeat purchases by 20% through personalized and targeted engagement campaigns.","Boosted CTR by 37% (2.55% to 3.5%) and managed ₹5 Cr monthly app revenue.","25 Cr+ ATL/BTL spends across locations to activate new users.","Established an in-house creative studio, enabling cost-effective and innovative campaign production.","Led content strategies for high-profile product launches like the 'Netflix of Foods' model.","Improved customer satisfaction by streamlining communications across key touchpoints."]},{"company":"RailYatri","role":"Growth Marketing Lead","duration":"Jan 2018 - Jan 2019","responsibilities":["Expanded MAUs by 77% (9M to 16M) and increased organic installs by 5X (5K to 25K).","Improved D90 retention by 15%, elevating commerce transactions and user satisfaction.","Devised engaging brand campaigns aligned with growth-focused app features for seamless user experiences.","Strategized content to resonate with user journeys and drive app-based growth."]},{"company":"Times Internet Limited","role":"Growth Manager","duration":"Sep 2015 - Jan 2018","responsibilities":["Managed a ₹26 Cr monthly budget, driving user base growth and retention across various brands including Times of India, ET Money, Gaana.com, News point, HDFC Times Card etc.","Increased D30 retention to 10%+, ensuring sustained repeat transactions and engagement.","Developed integrated content and branding strategies for flagship brands like Times of India and Gaana.","Collaborated on central marketing initiatives to drive growth across multiple digital and media platforms."]},{"company":"Printvenue.com","role":"Marketing Analyst","duration":"May 2013 - Sep 2015","responsibilities":["Sold products in three countries: India, Australia, and Singapore.","Responsible for maintaining Transactions, Transactions Growth, and Bucket Size.","Created and monitored campaigns on Google and Facebook platforms.","Scaled revenue from ₹1.9 Cr to ₹3.3 Cr monthly in India within 11 months.","Initiated online marketing campaigns in Australia, increasing daily transactions from 5 to 1009, with an average bucket size of $10.","Used Google Analytics to measure ROI, track ads, and monitor marketing campaigns across social networks, applications, and videos."]}]	\N	\N	2025-08-03 07:27:57.509258	2025-08-03 07:27:57.509258	Application	New Application	Pending	\N	\N	\N	{GTM,Performance,Brand,Growth,"Media Buying/Planning","Consumer & Data","Digital Marketing",Analytics,SEO,"Content Strategy","Campaign Management",Branding,"Customer Engagement"}	\N	\N	\N	https://www.linkedin.com/in/himanshumehta1991/	two	{}	1754206060014-501644338.pdf	15 days
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (id, name, website, careers_page, street1, street2, city, state, country, zipcode, linkedin, phone, tags, industry, size, currency, revenue, created_dt, updated_dt, email, contact_person) FROM stdin;
2	Acme Technologies	https://www.acmetech.com		123 Innovation Way	Suite 500	San Jose	California	USA	95112	https://www.linkedin.com/company/acmetech	+1-408-555-7890	{B2B,SaaS,Enterprise}	Finance	\N	\N	\N	2025-06-14 14:23:46.438161+00	2025-06-14 14:23:46.438161+00	abc@gmail.com	Annand Gupta
3	A1 Selectors	a1selectors.com	a1selectors.com	Noida		Noida	Uttar Pradesh	India	654321		9876543210	{Staffing,Recruitment}	Healthcare	\N	\N	\N	2025-06-14 15:19:49.183703+00	2025-06-14 15:19:49.183703+00	xez@gmail.com	Kumar Uttam
5	Dell Technologies	https://www.acmetech.com	https://www.acmetech.com	123 Innovation Way	Suite 500	San Jose	California	USA	95112	https://www.linkedin.com/company/acmetech	+1-408-555-7890	{B2B,SaaS,Enterprise}	Technology	\N	\N	\N	2025-06-14 15:43:40.537609+00	2025-06-14 15:43:40.537609+00	\N	Deepak Gupta
\.


--
-- Data for Name: contact_forms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_forms (id, name, email, subject, phone, message, created_at) FROM stdin;
1	Rahul Tripathi	rahul@example.com	Job Application	+91-7042094905	I am interested in the full stack developer position. Please find my resume attached.	2025-07-23 17:23:06.765
2	Rahul Tripathi	rahul@example.com	Job Application	+91-7042094905	I am interested in the full stack developer position. Please find my resume attached.	2025-07-23 17:52:25.034
3	undefined	undefined	undefined		undefined	2025-07-26 11:02:29.838
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interviews (id, application_id, scheduled_at, duration_minutes, type, interviewer) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jobs (id, job_title, job_code, department, workplace, office_primary_location, office_on_careers_page, office_location_additional, description_about, description_requirements, description_benefits, company_industry, company_job_function, employment_type, experience, education, keywords, salary_from, salary_to, salary_currency, status, priority, company, about_company, notice_period) FROM stdin;
18	Front End Developer	Job-001	Engineering	Hybrid	Noida	t	{Noida}	Test the jobs	Tets the requirnment	Test	IT services	Software	Full-time	Entry level	Associate	{}	0.00	0.00	INR	Paused	Medium	\N	\N	30 days
21	Java Developer	JAVA-001	Engineering	On-site	New York, NY	t	{London,Australia}	backend 	springboot	stipend + esops	IT	SDE	Full-time	Mid level	Master	{java,springboot}	100000.00	200000.00	USD	Draft	Medium	Hiring For Gamig Clients	Hiring For Gamig Clients	30 days
20	 Specialist -Training & Quality 	Job 1	Customer Succeess	Hybrid	Gurgaon	t	{}	Bachelor's degree\n● 3-5 years of relevant experience in training\n● Excellent communication skills, both verbal and written\n● Strong organizational skills to plan and execute training programs effectively\n● Strong interpersonal skills to build rapport with team leaders and stakeholders at all\nlevels\n● Proficiency in Microsoft Office Suite and any relevant training software/tools			Gaming	Customer Support 	Full-time	Mid level	Bachelor	{}	100000.00	1200000.00	INR	Paused	Medium	Hiring For Gamig Clients	Leading Gaming  Clients	30 days
19	back end developer	JOB-002	IT	Hybrid	Noida	t	{Noida}	Test the jobs	list the requirnment	list benifits	IT services	Software Development	Full-time	Mid level	High School	{node,php}	50000.00	100000.00	INR	Draft	Medium	A1 selectors	a1 selectors	30 days
25	Front End Job	Job-002	Engineering	Hybrid	Noida	t	\N	test the jobs	test the requirment	test the benifits	IT Services	Software Development	Part-time	Entry level	Bachelor	{php}	10000.00	20000.00	INR	Draft	Medium	Holidaytribe pvt ltd	test the company 	30 days
34	FrontEnd Developer	JOBS-34	Engineering	Hybrid	Delhi, Delhi	t	\N	description of job	List Requirnment	List Benifit	It Services	Software Development	Part-time	Entry level	High School	{}	10000.00	19998.00	INR	Closed	Medium	Abaan outsourcing	Describe the company	30 days
26	Front End Job	Job-002	Engineering	Hybrid	Noida	t	\N	test the jobs	test the requirment	test the benifits	IT Services	Software Development	Part-time	Entry level	Bachelor	{php}	10000.00	20000.00	INR	Open	Medium	Holidaytribe pvt ltd	test the company 	30 days
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_skills (id, skill, created_at) FROM stdin;
1	JavaScript	2025-07-26 11:03:13.235
2	JavaScript	2025-07-26 11:03:39.429
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, last_name, email, phone, password, birthday, gender, marital_status, address, pin_code, state, profile_pic, email_verified, phone_verified, login_otp, login_otp_valid, status, created_dt, token, role) FROM stdin;
2	Bob	Executive	executive@example.com	9999990002	hashed_password_2	1990-02-02	1	1	456 Executive Ln, City	654321	StateName	\N	0	1	\N	\N	1	2025-05-26 17:41:10.843797	\N	Recruiter
1	Alice	Admin	admin@ats.com	9999990001	$2b$10$psJladRk46EL/6kSF70IL.w8phumyXgoCeTLJOHt//XHot8Hl.AFm	1985-01-01	1	0	123 Admin St, City	123456	StateName	\N	1	1	\N	\N	1	2025-05-26 17:41:10.843797	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJkMDAwZTY4ZC00ODA1LTRiMTQtODY1NS1hZjBiMTg3ODhlNzAiLCJpYXQiOjE3NTI4MTc3NjcsImp0aSI6IjVlMGRiMjczLWVlZWEtNGE5OC05OWJiLTAxNWU2NzBjZjdiNCIsInN1YiI6MSwiZW1haWwiOiJhZG1pbkBhdHMuY29tIn0.0dLXCkiQc3xlcP5yl-M8p45sTHlZkE_zqUJSkw9aACo	Recruiter
4	Rahul	Tripathi	rahulknit008@gmail.com		$2b$10$wxtdLdfZ03Jm1k0bAYXEDuMO37pUNsdwTLiRol1h1Ae.ma3Y9EwQq	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-19 13:20:58.338474	\N	Recruiter
5	Rahul	Tripathi	rahulknit009@gmail.com		$2b$10$gBXp/2dAV594tGbodKstiecb41LcTNvQl8IcOx1SWLybXuXDu1KeS	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-19 13:30:14.18866	\N	Recruiter
6	Rahul	Tripathi	rahulknit010@gmail.com		$2b$10$5EQ.68Xsc6KSHztSGg/FLeuR/tgxoQyMf7DL3Uh1O86CjhJllzsPG	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-19 13:33:37.863734	\N	Recruiter
7	Rahul	Tripathi	rahulknit10@gmail.com		Admin@123	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-19 13:38:47.848287	\N	Recruiter
9	Atul		12112116@nitkkr.ac.in		$2b$10$IIhq3orS2IG17QMpZxhjSurUQmUx5/LllyNe6FKS6p5JjIZYA0f/m	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-19 13:43:08.685305	\N	Recruiter
10	Rahul	Tripathi	admin@ats.com		Admin@123	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-21 07:53:44.08037	\N	Recruiter
12	Recruiter	Name	recruiter@gmail.com		India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-29 10:18:11.449898	\N	Recruiter
13	Recruiter	Name	vendor@gmail.com		India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-29 10:18:35.600808	\N	Recruiter
14	Recruiter	Name	hm@gmail.com		India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-29 10:18:53.06745	\N	Recruiter
16	Recruiter	Name	candidate@gmail.com		India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-29 10:19:31.070419	\N	Recruiter
3	Charlie	Interviewer	interviewer@example.com	9999990003	hashed_password_3	1992-03-03	1	0	789 Interviewer Rd, City	789123	StateName	\N	1	0	\N	\N	1	2025-05-26 17:41:10.843797	\N	Interviewer
15	Recruiter	Name	interviewer@gmail.com		India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-29 10:19:14.681476	\N	Interviewer
18	Rahul	tripathi	rahul@gmail.com	7042094905	India@12345	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	0	2025-07-29 13:18:34.010288	\N	Candidate
19	Abha		hr@a1selectors.com		Anand@100	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-30 10:32:44.140234	\N	Recruiter
20	Anand	Gupta	anand@a1selectors.com		Anand@100	\N	1	0	\N	\N	\N	\N	0	0	\N	\N	1	2025-07-30 10:35:02.885824	\N	Recruiter
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 1, false);


--
-- Name: admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_id_seq', 1, false);


--
-- Name: applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.applications_id_seq', 1, false);


--
-- Name: candidate_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.candidate_notes_id_seq', 9, true);


--
-- Name: candidate_resumes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.candidate_resumes_id_seq', 23, true);


--
-- Name: candidate_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.candidate_task_id_seq', 14, true);


--
-- Name: candidates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.candidates_id_seq', 99, true);


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_id_seq', 17, true);


--
-- Name: contact_forms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.contact_forms_id_seq', 3, true);


--
-- Name: interviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.interviews_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jobs_id_seq', 34, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 20, true);


--
-- Name: user_skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_skills_id_seq', 2, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: candidate_jobs candidate_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_jobs
    ADD CONSTRAINT candidate_jobs_pkey PRIMARY KEY (candidate_id, job_id);


--
-- Name: candidate_notes candidate_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_notes
    ADD CONSTRAINT candidate_notes_pkey PRIMARY KEY (id);


--
-- Name: candidate_resumes candidate_resumes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_resumes
    ADD CONSTRAINT candidate_resumes_pkey PRIMARY KEY (id);


--
-- Name: candidate_task candidate_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_task
    ADD CONSTRAINT candidate_task_pkey PRIMARY KEY (id);


--
-- Name: candidates candidates_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_email_key UNIQUE (email);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: contact_forms contact_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contact_forms
    ADD CONSTRAINT contact_forms_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: users user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_skills user_skills_id_skill_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_id_skill_key UNIQUE (id, skill);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY (id);


--
-- Name: idx_client_city; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_city ON public.client USING btree (city);


--
-- Name: idx_client_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_country ON public.client USING btree (country);


--
-- Name: idx_client_created_dt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_created_dt ON public.client USING btree (created_dt);


--
-- Name: idx_client_industry; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_industry ON public.client USING btree (industry);


--
-- Name: idx_client_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_name ON public.client USING btree (name);


--
-- Name: idx_client_tags; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_tags ON public.client USING gin (tags);


--
-- Name: idx_client_updated_dt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_updated_dt ON public.client USING btree (updated_dt);


--
-- Name: candidate_jobs candidate_jobs_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_jobs
    ADD CONSTRAINT candidate_jobs_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: candidate_jobs candidate_jobs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_jobs
    ADD CONSTRAINT candidate_jobs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: candidate_notes candidate_notes_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_notes
    ADD CONSTRAINT candidate_notes_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: candidate_notes candidate_notes_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_notes
    ADD CONSTRAINT candidate_notes_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: candidate_resumes candidate_resumes_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_resumes
    ADD CONSTRAINT candidate_resumes_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: candidate_task candidate_task_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_task
    ADD CONSTRAINT candidate_task_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: candidate_task candidate_task_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.candidate_task
    ADD CONSTRAINT candidate_task_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON DELETE CASCADE;


--
-- Name: interviews interviews_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

